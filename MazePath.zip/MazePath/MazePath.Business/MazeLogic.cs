﻿using MazePath.Business.Models;
using System;
using System.Text;

namespace MazePath.Business
{
    public class MazeLogic
    {
        const string START_POINT = "A";
        const string END_POINT = "B";
        const string OPEN_ROAD = ".";
        const string CLOSE_ROAD = "#";
        const string SOLUTION_PATH = "@";

        /// <summary>
        /// Method to solve maze path
        /// </summary>
        /// <param name="mazeString">Input maze string</param>
        /// <returns>Solved maze</returns>
        public MapResult SolveMaze(string mazeString)
        {
            int steps = 0;
            MazeDetail mazeDetail = null;

            try
            {
                mazeDetail = GetMazeDeatail(mazeString);

                ValidateMaze(mazeDetail);

                string[,] trackMaze = new string[mazeDetail.Maze.GetLength(0), mazeDetail.Maze.GetLength(1)];
                Travese(mazeDetail.Maze, mazeDetail.StartPointRow, mazeDetail.StartPointColumn, trackMaze, ref steps);

                if (steps == 0)
                {
                    throw new Exception("No Path between start and end point.");
                }
            }
            catch (Exception)
            {
                //Logger.LogError(ex);
                throw;
            }

            return new MapResult()
            {
                Steps = steps,
                Solution = GetMazeString(mazeDetail.Maze)
            };
        }

        /// <summary>
        /// Gets maze details
        /// </summary>
        /// <param name="mazeString">Input maze strng</param>
        /// <returns>Maze related information</returns>
        private MazeDetail GetMazeDeatail(string mazeString)
        {
            MazeDetail mazeDetail = new MazeDetail();
            string[,] mazeArr = null;

            if (!string.IsNullOrEmpty(mazeString))
            {
                string[] rows = null;

                if (mazeString.Contains("\n"))
                {
                    rows = mazeString.Split(new[] { "\n" }, StringSplitOptions.None);
                }
                else
                {
                    rows = mazeString.Split(new[] { " " }, StringSplitOptions.None);
                }

                if (rows.Length > 0)
                {
                    int rowsCount = rows.Length;
                    int colCount = rows[0].ToCharArray().Length;

                    mazeArr = new string[rowsCount, colCount];

                    int rowInc = 0;
                    foreach (var row in rows)
                    {
                        var rowChars = row.ToCharArray();

                        for (int colInc = 0; colInc < rowChars.Length; colInc++)
                        {
                            var colValue = rowChars[colInc].ToString();

                            if (colValue == START_POINT)
                            {
                                mazeDetail.StartPointRow = rowInc;
                                mazeDetail.StartPointColumn = colInc;
                                mazeDetail.StartPointCount++;
                            }

                            if (colValue == END_POINT)
                            {
                                mazeDetail.EndPointCount++;
                            }

                            mazeArr[rowInc, colInc] = colValue;
                        }

                        rowInc++;
                    }
                }

                mazeDetail.Maze = mazeArr;
            }

            return mazeDetail;
        }

        /// <summary>
        /// Validates maze
        /// </summary>
        /// <param name="mazeDetail">Maze details</param>
        private void ValidateMaze(MazeDetail mazeDetail)
        {
            if (mazeDetail == null || mazeDetail.Maze == null)
            {
                throw new Exception("Invalid input maze.");
            }

            if (mazeDetail.StartPointCount == 0)
            {
                throw new Exception("Maze does not have start point.");
            }

            if (mazeDetail.EndPointCount == 0)
            {
                throw new Exception("Maze does not have end point.");
            }

            if (mazeDetail.StartPointCount > 1)
            {
                throw new Exception("More than one start point exist in maze.");
            }

            if (mazeDetail.EndPointCount > 1)
            {
                throw new Exception("More than one end point exist in maze.");
            }
        }

        /// <summary>
        /// Recurcive method to find maze path
        /// </summary>
        /// <param name="maze">Input maze</param>
        /// <param name="row">Starting point row index</param>
        /// <param name="column">Starting point column index</param>
        /// <param name="trackMaze">Maze to trak visited elements</param>
        /// <param name="steps">No of step required from start point to end point</param>
        /// <returns>Return move to next or not</returns>
        private bool Travese(string[,] maze, int row, int column, string[,] trackMaze, ref int steps)
        {
            if (maze[row, column] == END_POINT)
            {
                steps++;
                return true;
            }

            if (trackMaze[row, column] != "T")
            {
                trackMaze[row, column] = "T";

                ////Right
                if (CanMove(maze, row, column + 1) && Travese(maze, row, column + 1, trackMaze, ref steps))
                {
                    if (maze[row, column + 1] != END_POINT)
                    {
                        maze[row, column + 1] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                //Bottom
                if (CanMove(maze, row + 1, column) && Travese(maze, row + 1, column, trackMaze, ref steps))
                {
                    if (maze[row + 1, column] != END_POINT)
                    {
                        maze[row + 1, column] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                ////Top
                if (CanMove(maze, row - 1, column) && Travese(maze, row - 1, column, trackMaze, ref steps))
                {
                    if (maze[row - 1, column] != END_POINT)
                    {
                        maze[row - 1, column] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                //Left
                if (CanMove(maze, row, column - 1) && Travese(maze, row, column - 1, trackMaze, ref steps))
                {
                    if (maze[row, column - 1] != END_POINT)
                    {
                        maze[row, column - 1] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Validates column based on provided index values
        /// </summary>
        /// <param name="maze">Input maze</param>
        /// <param name="row">Next column row index</param>
        /// <param name="column">Next column column index</param>
        /// <returns> Can move to next element or not</returns>
        private bool CanMove(string[,] maze, int row, int column)
        {
            return (row >= 0 && row <= maze.GetLength(0) - 1 && column >= 0 && column <= maze.GetLength(1) - 1 && (maze[row, column] == OPEN_ROAD || maze[row, column] == END_POINT));
        }

        /// <summary>
        /// Gets solved maze string
        /// </summary>
        /// <param name="maze">Maze array</param>
        /// <returns>Solved maze as string</returns>
        private string GetMazeString(string[,] maze)
        {
            StringBuilder mazeOutput = new StringBuilder();

            for (int rowInc = 0; rowInc < maze.GetLength(0); rowInc++)
            {
                for (int colInc = 0; colInc < maze.GetLength(1); colInc++)
                {
                    mazeOutput.Append(maze[rowInc, colInc]);
                }

                mazeOutput.Append("\n");
            }

            return mazeOutput.ToString();
        }
    }
}
