﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazePath.Business.Models
{
    public class MazeDetail
    {
        public string[,] Maze
        {
            get;
            set;
        }

        public int StartPointRow
        {
            get;
            set;
        }

        public int StartPointColumn
        {
            get;
            set;
        }

        public int StartPointCount
        {
            get;
            set;
        }

        public int EndPointCount
        {
            get;
            set;
        }
    }
}
