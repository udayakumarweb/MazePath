﻿
namespace MazePath.Business.Models
{
    public class MapRequest
    {
        public string MazeString
        {
            get;
            set;
        }
    }
}