﻿using System.Collections.Generic;

namespace MazePath.Business.Models
{
    public class MapResult
    {
        public int Steps
        {
            get;
            set;
        }

        public string Solution
        {
            get;
            set;
        }
    }
}