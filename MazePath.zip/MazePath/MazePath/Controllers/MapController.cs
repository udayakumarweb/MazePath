﻿using MazePath.Business;
using MazePath.Business.Models;
using System;
using System.Web.Http;

namespace MazePath.Controllers
{
    [RoutePrefix("api/Map")]
    public class MapController : ApiController
    {
        [HttpPost]
        [Route("SolveMaze")]
        public IHttpActionResult SolveMaze(MapRequest mapRequest)
        {
            try
            {
                MapResult mapResult = new MazeLogic().SolveMaze(mapRequest.MazeString);

                return Ok(mapResult);
            }
            catch (Exception ex)
            {
                //Logger.LogException(ex);
                //This object is used to display error messages in test client.
                return BadRequest(ex.Message);
            }
        }
    }
}
